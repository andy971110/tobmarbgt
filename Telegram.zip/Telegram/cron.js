var TelegramBot = require('node-telegram-bot-api');
var request = require('request');
var CronJob = require('cron').CronJob;
var MongoClient = require('mongodb').MongoClient;
var dbConfig = 'mongodb://dronich:15975300f@ds011321.mlab.com:11321/lentabot';
var token = '301685092:AAHIvFKai4h3lrvo5GaQ8cDM72zVI-ypWWw';
var bot = new TelegramBot (token, {polling: true});
var i=null;
var j=null;
var count = null;
var k = null;

var job1 = new CronJob ('*/20 * * * * *', function() {
	MongoClient.connect(dbConfig, function(err, db){

		var stats = db.collection("stats");
		var collection = db.collection("users");
		var stat = null;
		stats.find().toArray(function(err, docs) {
			stat = docs[0];
			count = stat.count;
			for(i=0;i<count;i++){		
				(function(i) {
					console.log('1-'+i);
					for(j=1;j<=10;j++){
						(function(j) {			
							collection.find()
							.toArray(function(err, docs) {
								var user = docs[i];
								var URL = 'https://api.telegram.org/bot301685092:AAHIvFKai4h3lrvo5GaQ8cDM72zVI-ypWWw/forwardMessage?chat_id='+user.ChatID+'&from_chat_id='+user['uid' + j]+'&message_id='+user['id_m' + j];
								console.log(URL);
								request(URL, function(error, response, body){
									var date = JSON.parse(body);
									chatIdr = date.chat_id;
									id_mr = date.forward_from_message_id;
									uidr = date.forward_from_chat_id;

									if(date.ok === true){
										collection.updateOne({ ChatId: user.ChatId }
											, { $set: { ['id_m' + j]: user['id_m' + j]+1
										} }, function(err, result) {
										});	
										console.log("Ошибки нет");
									}
									if(date.ok === false){
										if(date.description === 'Bad Request: MESSAGE_ID_INVALID'){
											collection.updateOne({ ChatId: user.ChatId }
												, { $set: { ['id_m' + j]: user['id_m' + j]+1
											} }, function(err, result) {
											});
										}						
									}

								});	
							});
						})(j);
					}
				})(i);

			}	
		});	
	});		
});

