function getAdmin(chatId, channelId){
	var URLq = 'https://api.telegram.org/bot301685092:AAHIvFKai4h3lrvo5GaQ8cDM72zVI-ypWWw/getChatAdministrators?chat_id='+channelId;
	request(URLq, function(error, response, body){
		console.log("3."+body);
		var datef = JSON.parse(body);
		var user = datef.result[user];
		if(datef.ok == true){				
			console.log("Вы добавили канал");
			console.log("3."+user);
			return;
		}else{
			console.log("Добавьте бота в Администраторы канала");
		}	
//&& date1.result.user.id == 301685092
});
}

var job1 = new CronJob ('*/3 * * * * *', function() {
	console.log(URL);

	request(URL, function(error, response, body){
		var date = JSON.parse(body);
		console.log("1."+id_m);
		chatIdr = date.chat_id;
		id_mr = date.forward_from_message_id;
		uidr = date.forward_from_chat_id;

		if(date.ok === true){
			id_m = id_m + 1;	
			console.log("Ошибки нет");
		}
		if(date.ok === false){
			console.log("2."+date.error_code);
			if(date.description === 'Bad Request: MESSAGE_ID_INVALID'){
				id_m=id_m+1;
			}						
		}

		console.log("3."+body);
		console.log("4."+uid);

	});	
	URL = 'https://api.telegram.org/bot301685092:AAHIvFKai4h3lrvo5GaQ8cDM72zVI-ypWWw/forwardMessage?chat_id='+chatIdr+'&from_chat_id='+uidr+'&message_id='+id_mr;

});

bot.on('message', function (msg) {
	var id = msg.from.id;

	if(msg.forward_from){
		bot.sendMessage(chatId, "Это сообщение не из канала");
	}

	if(msg.forward_from_chat){
			//var id_m = msg.forward_from_message_id+1;
			if(uname ==='@' + msg.forward_from_chat.username){
				bot.sendMessage(chatId, "Канал "+uname+" уже добавлен!");
				var k = 1;
			}

			if(uname === "Пусто"){
				var id_m = msg.forward_from_message_id+1;
				uname = '@' + msg.forward_from_chat.username;
				uid = msg.forward_from_chat.id;
				bot.sendMessage(chatId, "Канал "+uname+" добавлен!");
				channelN--;
				console.log("0."+id_m);
				cron1(jobActive);
				return;
			}
			else if(uname1 === "Пусто" && k!=1){			
				var id_m1 = msg.forward_from_message_id+1;
				uname1 = '@' + msg.forward_from_chat.username;
				uid1 = msg.forward_from_chat.id;
				bot.sendMessage(chatId, "Канал "+uname1+" добавлен!");
				channelN--;
				console.log("-1."+id_m);
				//cron1(chatId, id_m1, uid1);
			}
			else if(k!=1){
				bot.sendMessage(chatId, "Вы больше не можете добавлять каналы");
			}
		}
	});

function cron_pr(chatId, id_m, uid){
	var chId = chatId;
	var idm = id_m;
	var idch = uid;
	var URL = 'https://api.telegram.org/bot301685092:AAHIvFKai4h3lrvo5GaQ8cDM72zVI-ypWWw/forwardMessage?chat_id='+chId+'&from_chat_id='+idch+'&message_id=';
	console.log('Запуск крона проверки');
	for(var i = idm+1; i<idm+25; i++){					
		console.log("1."+i);
		request(URL+i+"'", function(error, response, body){
			var date = JSON.parse(body);
			console.log("2."+i);

			if(date.ok === true){
				id_m = idm+1;				
				console.log("Нашёлся новый пост");
				console.log("3."+body);
				break;
			}


		});
	}		

}

function cron1(jobActive){
	if(jobActive===0){	
		console.log('Запуск 1 крона');		
		job1.start();		
	}else{
		job1.stop();
	}
}

		/*if(uname === "Пусто"){
			var id_m = msg.forward_from_message_id+1;
			uname = '@' + msg.forward_from_chat.username;
			uid = msg.forward_from_chat.id;
			bot.sendMessage(chatId, "Канал "+uname+" добавлен!");
			console.log("0."+id_m);
			editAccess(chatId, name, uid, id_m, uname);
			uname = "Пусто";
			return;
		}
		else if(uname1 === "Пусто" && k!=1){			
			var id_m1 = msg.forward_from_message_id+1;
			uname1 = '@' + msg.forward_from_chat.username;
			uid1 = msg.forward_from_chat.id;
			bot.sendMessage(chatId, "Канал "+uname1+" добавлен!");
			console.log("-1."+id_m);
		}
		else if(k!=1){
			bot.sendMessage(chatId, "Вы больше не можете добавлять каналы");
		}*/