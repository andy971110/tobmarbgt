var TelegramBot = require('node-telegram-bot-api'),
    MongoClient = require('mongodb').MongoClient
    dbConfig = 'mongodb://admin:admin@ds151697.mlab.com:51697/geekbrains-bot',
    token = '272536507:AAHiOiIRZCUwqTtI8voYz7VKfHYARBMctiI',
    bot = new TelegramBot(token, { polling: true });

var _login = null;
var _password = null;
var field = null;

bot.on('message', function(msg) {
   var chatId = msg.from.id;

  if (msg.text == '/войти') {
    field = 'login';
    login(chatId);
  }
  else if (login != null) {
    login(chatId, msg.text);
  }
  else {
    defaultCommand(chatId);
  }
})

function login(chatId, text) {
  if (field == 'login') {
    if (text) {
      _login = text;
      field = 'password';
      text = null;
    }
    else {
      bot.sendMessage(chatId, 'Введите ваш логин');
    }
  }
  if (field == 'password') {
    if (text) {
      _password = text;
      checkAccess(chatId);
    }
    else {
      bot.sendMessage(chatId, 'Введите ваш пароль');
    }
  }
}

function checkAccess(chatId) {
  MongoClient.connect(dbConfig, function(err, db) {
    var collection = db.collection('user');

    collection.find({
      login: _login
    })
    .toArray(function(err, docs) {
      var user = docs[0];

      if (user && user.password == _password) {
        bot.sendMessage(chatId, 'Вы вошли в систему!');
      }
      else {
        bot.sendMessage(chatId, 'Неверное имя или пароль');
      }

      _login = null;
      _password = null;
      field = null;

    });

    
    db.close();
  });

}

function defaultCommand(chatId) {
  bot.sendMessage(chatId, 'Добрый день! Это команда по умолчанию :)');
}