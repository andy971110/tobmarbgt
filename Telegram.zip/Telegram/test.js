var TelegramBot = require('node-telegram-bot-api');
var CronJob = require('cron').CronJob;
var request = require('request');
var token = '301685092:AAHIvFKai4h3lrvo5GaQ8cDM72zVI-ypWWw';
var bot = new TelegramBot (token, {polling: true});


bot.on('message', function (msg) {
  var chatId = msg.chat.id;
  switch (msg.text) {
    case '/start':
      	start(chatId);      
    	break;
    case '1.':
	      {

	      }
	    break;
	case '2.':
	    start(chatId);
	    break;
	case 'Назад':{
	    start(chatId);	    
	   	break;
		}
	case 'Меню':
	    start(chatId);	    
	   	break;
	case 'Просмотр':
		view(chatId);
		break;
}
});

function start(chatId) {	
	bot.sendMessage(chatId, 'Функция старт', {
	    reply_markup: JSON.stringify({
	    	one_time_keyboard: true,
	      	keyboard: [
	        ['Меню'],
	        ['Просмотр']]
	    })
	});	
	}

function view(chatId){
		bot.sendMessage(chatId, 'Привет', {
	    reply_markup: JSON.stringify({
	      keyboard: [
	        ['1.'],
	        ['2.'],
	        ['Назад']]
	    })
	  });

}